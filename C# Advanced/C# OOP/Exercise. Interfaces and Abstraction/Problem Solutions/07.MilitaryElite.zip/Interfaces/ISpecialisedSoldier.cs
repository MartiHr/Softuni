﻿using _07.MilitaryElite.Enumerations;

namespace _07.MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        public SoldierCorpsEnum Corps { get; set; }
    }
}
