﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Enumerations
{
    public enum MissionStateEnum
    {
        inProgress = 1,
        Finished = 2
    }
}
