﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(double quantity) 
            : base(quantity)
        {
        }
    }
}
